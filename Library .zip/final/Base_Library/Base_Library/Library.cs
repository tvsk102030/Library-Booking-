﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Base_Library
{
    public enum RoomType
    {
        AssignmentWork = 1,
        GroupStudy = 2,
        PresentationPractice = 3
    }
    public abstract class Library : ILibrary
    {
        private int sid; // Student Id
        private string date; // Date
        private string tslot; // Tslot
        private LibraryWork theDelegate = null; // Delegate
        
        //Constractors
        public Library()
        {
            SetDel();
        }
        public Library(int sid, string date, string tslot)
        {
            this.sid = sid;
            this.date = date;
            this.tslot = tslot;
            SetDel();
        }

        //properties
        public int Sid { get => sid; set => sid = value; }
        public string Date { get => date; set => date = value; }
        public string Tslot { get => tslot; set => tslot = value; }
        [XmlIgnore]
        public LibraryWork TheDelegate { get => theDelegate; set => theDelegate = value; }

        //operations
        public void QrCode()
        {
            Console.WriteLine("-> Your QR card has been generated. You can use it for accessing the library room.");
        }
        public void TemporaryIdPwd()
        {
            Console.WriteLine("-> Your temporary Id and Password has been generated. You can use it for accessing any machine of library.");
        }

        //extra operation
        public abstract void Extra();

        //ToString
        public override string ToString()
        {
            return string.Format($"Student's Id is {sid}, he or she has booked libray room for {date} and time {tslot}");
        }

        //Delegate
        private void SetDel()
        {
            theDelegate += QrCode;
            theDelegate += TemporaryIdPwd;
            //theDelegate += Extra();
        }
    }
}
