﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Base_Library
{
    public delegate void LibraryWork(); 
    public interface ILibrary
    {
        int Sid { get; set; }
        string Date { get; set; }
        string Tslot { get; set; }
        LibraryWork TheDelegate { get; set; }

        void QrCode();
        void TemporaryIdPwd();
        void Extra();
    }
}
