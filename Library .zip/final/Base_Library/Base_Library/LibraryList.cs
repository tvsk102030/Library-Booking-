﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Base_Library
{
    [XmlRoot("Library_List")]
    [XmlInclude(typeof(AssignmentWork))]
    [XmlInclude(typeof(GroupStudy))]
    [XmlInclude(typeof(PresentationPractice))]
    public class LibrabryList
    {
        private List<Library> libList = null;

        [XmlArray("Students")]
        [XmlArrayItem("Student", typeof(Library))]
        public List<Library> LibList { get => libList; set => libList = value; }

        public LibrabryList()
        {
            LibList = new List<Library>();
        }
        public Library this[int i]
        {
            get { return LibList[i]; }
            set { LibList[i] = value; }
        }
        public void Add(Library l)
        {
            LibList.Add(l);
        }
        public void Remove(Library l)
        {
            LibList.Remove(l);
        }
        public int Count()
        {
            return LibList.Count();
        }
        public void Clear()
        {
            LibList.Clear();
        }
    }
}
