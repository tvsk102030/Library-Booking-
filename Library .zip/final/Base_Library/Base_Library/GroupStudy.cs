﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Base_Library
{
    public class GroupStudy : Library
    {
        public GroupStudy()
        { }
        public GroupStudy(int sid, string date, string tslot) : base(sid, date, tslot)
        {}
        public override void Extra()
        {
            Console.WriteLine("-> In this room there will be total 10 chairs and 2 big study table.");
        }
        public override string ToString()
        {
            return base.ToString();
        }
    }
}
