﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Base_Library
{
    public class PresentationPractice : Library
    {
        public PresentationPractice()
        { }
        public PresentationPractice(int sid, string date, string tslot) : base(sid, date, tslot)
        {}
        public override void Extra()
        {
            Console.WriteLine("-> In this room there will be total 4 chairs and access to big-projector.");
        }
        public override string ToString()
        {
            return base.ToString();
        }
    }
}
