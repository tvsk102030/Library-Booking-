﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace FinalProject
{
    public class Sid_Rule : ValidationRule
    {
        int min;
        int max;

        public int Min { get => min; set => min = value; }
        public int Max { get => max; set => max = value; }

        public override ValidationResult Validate(object value, CultureInfo cultureInfo)
        {
            int tempVal = 0;
            if (!int.TryParse(value.ToString(), out tempVal))
            {
                return new ValidationResult(false, "Invalid data");
            }

            if (tempVal < min || tempVal > max)
            {
                return new ValidationResult(false, "Out of Range!!");
            }

            return ValidationResult.ValidResult;
        }
    }
}
