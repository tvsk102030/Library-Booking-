﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Base_Library;

namespace FinalProject
{
    public class MyLibrary:Library
    {
        string type;
        Library innerLibrary;

        public string Type { get => type; set => type = value; }
        internal Library InnerLibrary { get => innerLibrary; set => innerLibrary = value; }

        public override void Extra()
        {
            throw new NotImplementedException();
        }
    }
}
