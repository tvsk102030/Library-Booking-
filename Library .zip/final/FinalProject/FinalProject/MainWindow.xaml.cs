﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Serialization;
using Base_Library;

namespace FinalProject
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        ObservableCollection<MyLibrary> displayData = null;
        LibrabryList LL = new LibrabryList();
        MyLibrary aLib = new MyLibrary();

        public ObservableCollection<MyLibrary> DisplayData { get => displayData; set => displayData = value; }
        public MyLibrary ALib { get => aLib; set => aLib = value; }

        public MainWindow()
        {
            InitializeComponent();

            DisplayData = new ObservableCollection<MyLibrary>();
            DataContext = this;

            //delete previous file
            if (File.Exists("booking_data.xml"))
            {
                File.Delete("booking_data.xml");
            }
        }

        private void Sid_KeyUp(object sender, KeyEventArgs e)
        {
            int x = 0;
            if (!int.TryParse(sid.Text, out x) || ((x < 1) || (x > 999999)))
                sid.SetCurrentValue(ForegroundProperty, Brushes.Red);
            else
                sid.SetCurrentValue(ForegroundProperty, Brushes.Black);
        }
        private void ClearSelection()
        {
            sid.Text = null;
            rtype.SelectedIndex = 0;
            date.Text = null;
            time.SelectedIndex = 0; 
        }
        private void Add_btn_Click(object sender, RoutedEventArgs e)
        {
            if(sid.Foreground == Brushes.Black && rtype.SelectedIndex>=1 && date.Text!=" " && time.SelectedIndex>=1)
            {
                //MessageBox.Show($"{sid.Text},{rtype.SelectedValue},{date.Text},{time.SelectedValue}");
                MyLibrary newStu = new MyLibrary();

                newStu.Sid = int.Parse(sid.Text); // student id
                newStu.Date = date.Text; // booking date
                newStu.Tslot = time.Text; // time slot

                newStu.Type = rtype.Text; // room type

                Library l = null;

                switch(rtype.SelectedIndex)
                {
                    case 1:
                        l = new AssignmentWork(int.Parse(sid.Text),date.Text,time.Text) { };
                        break;
                    case 2:
                        l = new GroupStudy(int.Parse(sid.Text), date.Text, time.Text) { };
                        break;
                    case 3:
                        l = new PresentationPractice(int.Parse(sid.Text), date.Text, time.Text) { };
                        break;
                }
                newStu.InnerLibrary = l;
                //DisplayData.Add(newStu);

                //check for redundent data
                bool flag = true;
                for(int i=0;i<LL.Count();i++)
                {
                    if(LL[i].GetType()==l.GetType() && LL[i].Date==newStu.Date && LL[i].Tslot==newStu.Tslot)
                    {
                        MessageBox.Show("Someone has already booked room for given Date & Time, please select other timeslot.");
                        flag = false;
                        break;
                    } 
                }

                if(flag==true)
                {
                    LL.Add(newStu.InnerLibrary);
                    MessageBox.Show("Record inserted!", "Added");
                    ClearSelection();
                }
            }
            else
            {
                MessageBox.Show("Please enter valid details.","Wrong Input!");
            }
        }
        private void WriteXML()
        {
            XmlSerializer serializer = new XmlSerializer(typeof(LibrabryList));
            TextWriter tw = new StreamWriter("booking_data.xml");
            serializer.Serialize(tw, LL);
            tw.Close();
        }
 
        private void ReadXML()
        {
            XmlSerializer serializer = new XmlSerializer(typeof(LibrabryList));
            TextReader tr = new StreamReader("booking_data.xml");
            LL = (LibrabryList)serializer.Deserialize(tr);
            tr.Close();
        }

        private void Save_btn_Click(object sender, RoutedEventArgs e)
        {
            if (LL.Count() > 0)
            {
                WriteXML(); // write data to file

                MessageBox.Show("Data has been saved.");
            }
            else
            {
                MessageBox.Show("Nothing to save / Already saved all records.");
            }
        }

        private void Dis_btn_Click(object sender, RoutedEventArgs e)
        {
            if(File.Exists("booking_data.xml"))
            { 
                LL.Clear(); // list clearance, because now we are going to read data 

                ReadXML(); // Read data from file

                DisplayData.Clear(); // clear grid

                for(int i=0;i<LL.Count();i++)
                {
                    Library l = LL[i];
                    MyLibrary newlib = new MyLibrary();

                    newlib.Sid = l.Sid; // student id
                    newlib.Date = l.Date; // booking date
                    newlib.Tslot = l.Tslot; // time slot


                    string[] arrStr = l.GetType().ToString().Split('.');
                    string fullType = arrStr[arrStr.Length - 1];
                    newlib.Type = fullType;

                    DisplayData.Add(newlib);
                }
                d_grid.ItemsSource = DisplayData;
            }
            else
            {
                MessageBox.Show("Nothing to display");
            }
        }

        private void Search_btn_Click(object sender, RoutedEventArgs e)
        {
            if(q_tb.Text!=string.Empty)
            {
                if((bool)sby_rt.IsChecked)
                {
                    var q = from my in DisplayData
                            where my.Type == q_tb.Text
                            select my;

                    d_grid.ItemsSource = q;
                }
                else if((bool)sby_sid.IsChecked)
                {
                    var q = from my in DisplayData
                            where my.Sid == int.Parse(q_tb.Text)
                            select my;

                    d_grid.ItemsSource = q;
                }
            }
            else
            {
                MessageBox.Show("Please enter valid input!");
            }
        }
    }
}
